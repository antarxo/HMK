# Drop-in αρχεία για Git/Netlify

Βάλε τα αρχεία στις ίδιες σχετικές θέσεις μέσα στο repository:

- `book/chapter_content.json` αντικαθιστά το υπάρχον `book/chapter_content.json`.
- `electrostatic_field_book_ready.html` μπαίνει στη ρίζα του repository, δίπλα στο βασικό `index.html` της εφαρμογής ΗΜ κύματος.

Το JSON περιέχει τις δύο νέες προσωρινές σελίδες στο τέλος και τα `singleSrc` δείχνουν σε:

- `../electrostatic_field_book_ready.html?p=charge&lang=el`
- `../electrostatic_field_book_ready.html?p=dipole&lang=el`

Δεν περιλαμβάνεται `book/index.html`, γιατί δεν χρειάζεται αλλαγή.
