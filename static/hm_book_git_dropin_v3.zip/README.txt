Drop-in v3

Αντικατάσταση/προσθήκη στο Git project:

1) /project-root/electrostatic_field_book_ready.html
2) /project-root/book/chapter_content.json
3) /project-root/book/index.html

Οι δύο ηλεκτροστατικές σκηνές έχουν μετακινηθεί μετά το τέλος του Παραρτήματος Α και πριν από το Παράρτημα Β.
Το book/index.html δεν ζητά πλέον chapter_content_bilingual.json.
