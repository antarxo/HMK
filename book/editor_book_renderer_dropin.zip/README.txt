Drop-in για ενοποίηση renderer editor/book.

Τοποθέτηση:
- Editor.html -> στη θέση του υπάρχοντος Editor.html
- book/index.html -> στη θέση του υπάρχοντος book/index.html

Δεν περιέχει JSON και δεν αλλάζει περιεχόμενο βιβλίου.
