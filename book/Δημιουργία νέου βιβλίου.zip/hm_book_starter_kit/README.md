# Starter kit ηλεκτρονικού βιβλίου

Περιεχόμενα:
- `Editor.html`: εργαλείο συγγραφής/σελιδοποίησης.
- `index.html`: viewer για δημοσίευση.
- `chapter_content.json`: καθαρό starter JSON.
- `images/`: φάκελος για εικόνες/σχήματα.

Ροή:
1. Άνοιγμα του `Editor.html`.
2. Φόρτωση του `chapter_content.json`.
3. Δημιουργία σελίδων/items.
4. Export JSON.
5. Αντικατάσταση του `chapter_content.json` δίπλα στο `index.html`.
6. Δημοσίευση όλου του φακέλου.
